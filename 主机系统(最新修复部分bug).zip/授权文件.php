<?php
//用户授权文件，搭配后台/admin中的授权中心使用
//不用此功能就不管这个文件
//把下面文件放在前台所有控制器下的_initialize里使用
//记得替换下面的"你的域名"，不加<?php
//这里加<?php是为了美观
$data=md5($_SERVER['HTTP_HOST'].$_SERVER['REMOTE_ADDR']);
$session=session($data);
if($session!="1"){
$domain="你的域名/sq";
$get=@json_decode(@file_get_contents($domain."?domain=".$_SERVER["HTTP_HOST"]),true);
if($get["code"]!="1"){
exit($get["msg"]);
}else{
session($data,"1");
}
}

