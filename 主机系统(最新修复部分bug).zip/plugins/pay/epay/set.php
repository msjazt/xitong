<?php
$data=[
["name"=>"epayurl",'title'=>'epayurl', 'type'=>'input',"prompt"=>"易支付链接","value"=>""],

["name"=>"epayid",'title'=>'epayid', 'type'=>'input',"prompt"=>"易支付ID","value"=>""],

["name"=>"epaykey",'title'=>'epaykey', 'type'=>'input',"prompt"=>"易支付密钥","value"=>""],

["name"=>"支付方式",'title'=>'支付方式', 'type'=>'select',"prompt"=>"支付方式","value"=>"支付宝","option"=>["支付宝","微信","QQ"]],


];
return $data;