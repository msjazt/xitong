<?php
$data=[
["name"=>"appId",'title'=>'APPID', 'type'=>'input',"prompt"=>"APPID","value"=>""],

["name"=>"rsaPrivateKey",'title'=>'应用私钥', 'type'=>'textarea',"prompt"=>"应用私钥","value"=>""],

["name"=>"alipayrsaPublicKey",'title'=>'支付宝公钥', 'type'=>'textarea',"prompt"=>"支付宝公钥","value"=>""],



];
return $data;