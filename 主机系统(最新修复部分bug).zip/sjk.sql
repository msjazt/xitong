-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: admin
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dd_admin`
--

DROP TABLE IF EXISTS `dd_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `qq` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `password` varchar(288) NOT NULL,
  `mail` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_admin`
--

LOCK TABLES `dd_admin` WRITE;
/*!40000 ALTER TABLE `dd_admin` DISABLE KEYS */;
INSERT INTO `dd_admin` VALUES (1,'没事就爱折腾','2150811531','admin','$2y$10$MgZM3u4783aTERsO9jJSmu83KVYYIVxIhNR9kkHzjdU1/6tiM97kO','2150811531@qq.com');
/*!40000 ALTER TABLE `dd_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_affsymoney`
--

DROP TABLE IF EXISTS `dd_affsymoney`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_affsymoney` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `information` text NOT NULL,
  `money` varchar(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `time` varchar(50) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_affsymoney`
--

LOCK TABLES `dd_affsymoney` WRITE;
/*!40000 ALTER TABLE `dd_affsymoney` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_affsymoney` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_afftxjl`
--

DROP TABLE IF EXISTS `dd_afftxjl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_afftxjl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `information` text NOT NULL,
  `money` varchar(100) NOT NULL,
  `state` varchar(10) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `time` varchar(50) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_afftxjl`
--

LOCK TABLES `dd_afftxjl` WRITE;
/*!40000 ALTER TABLE `dd_afftxjl` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_afftxjl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_announcement`
--

DROP TABLE IF EXISTS `dd_announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_announcement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `information` text NOT NULL,
  `time` varchar(288) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_announcement`
--

LOCK TABLES `dd_announcement` WRITE;
/*!40000 ALTER TABLE `dd_announcement` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_cart`
--

DROP TABLE IF EXISTS `dd_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `money` varchar(200) NOT NULL DEFAULT '0',
  `cycle` varchar(100) NOT NULL,
  `firstmo` varchar(288) NOT NULL DEFAULT '0',
  `serverid` varchar(200) NOT NULL,
  `upgrade` varchar(10) NOT NULL DEFAULT '0',
  `upgrades` text,
  `buy` varchar(10) NOT NULL DEFAULT '0',
  `hide` varchar(10) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `renew` varchar(100) NOT NULL DEFAULT '0',
  `limits` varchar(288) NOT NULL DEFAULT '0',
  `inventory` varchar(100) NOT NULL DEFAULT '0',
  `data1` text,
  `data2` text,
  `data3` text,
  `data4` text,
  `data5` text,
  `data6` text,
  `data7` text,
  `data8` text,
  `data9` text,
  `data10` text,
  `data11` text,
  `data12` text,
  `data13` text,
  `data14` text,
  `data15` text,
  `data16` text,
  `data17` text,
  `data18` text,
  `data19` text,
  `data20` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_cart`
--

LOCK TABLES `dd_cart` WRITE;
/*!40000 ALTER TABLE `dd_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_order`
--

DROP TABLE IF EXISTS `dd_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `userid` varchar(100) NOT NULL,
  `cartid` varchar(100) NOT NULL,
  `atime` varchar(300) NOT NULL,
  `ztime` varchar(300) NOT NULL,
  `state` varchar(200) NOT NULL,
  `data1` text,
  `data2` text,
  `data3` text,
  `data4` text,
  `data5` text,
  `data6` text,
  `data7` text,
  `data8` text,
  `data9` text,
  `data10` text,
  `data11` text,
  `data12` text,
  `data13` text,
  `data14` text,
  `data15` text,
  `data16` text,
  `data17` text,
  `data18` text,
  `data19` text,
  `data20` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_order`
--

LOCK TABLES `dd_order` WRITE;
/*!40000 ALTER TABLE `dd_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_pay`
--

DROP TABLE IF EXISTS `dd_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(288) NOT NULL,
  `ordernumber` varchar(288) NOT NULL,
  `pay` varchar(288) NOT NULL,
  `money` varchar(288) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `time` varchar(288) NOT NULL,
  `state` varchar(288) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_pay`
--

LOCK TABLES `dd_pay` WRITE;
/*!40000 ALTER TABLE `dd_pay` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_pays`
--

DROP TABLE IF EXISTS `dd_pays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_pays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(288) NOT NULL,
  `plugins` varchar(288) NOT NULL,
  `state` varchar(10) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_pays`
--

LOCK TABLES `dd_pays` WRITE;
/*!40000 ALTER TABLE `dd_pays` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_pays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_product`
--

DROP TABLE IF EXISTS `dd_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `introduce` text NOT NULL,
  `hide` varchar(10) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_product`
--

LOCK TABLES `dd_product` WRITE;
/*!40000 ALTER TABLE `dd_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_server`
--

DROP TABLE IF EXISTS `dd_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `host` varchar(100) NOT NULL,
  `ip` varchar(200) NOT NULL,
  `security` text NOT NULL,
  `port` varchar(200) NOT NULL,
  `ssl` varchar(200) NOT NULL DEFAULT '0',
  `user` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `serverplugins` varchar(288) NOT NULL,
  `data1` text,
  `data2` text,
  `data3` text,
  `data4` text,
  `data5` text,
  `data6` text,
  `data7` text,
  `data8` text,
  `data9` text,
  `data10` text,
  `data11` text,
  `data12` text,
  `data13` text,
  `data14` text,
  `data15` text,
  `data16` text,
  `data17` text,
  `data18` text,
  `data19` text,
  `data20` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_server`
--

LOCK TABLES `dd_server` WRITE;
/*!40000 ALTER TABLE `dd_server` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_sq`
--

DROP TABLE IF EXISTS `dd_sq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_sq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` text NOT NULL,
  `qq` varchar(288) NOT NULL,
  `ip` varchar(288) NOT NULL,
  `time` varchar(288) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_sq`
--

LOCK TABLES `dd_sq` WRITE;
/*!40000 ALTER TABLE `dd_sq` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_sq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_ticket`
--

DROP TABLE IF EXISTS `dd_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(288) NOT NULL,
  `content` mediumtext NOT NULL,
  `userid` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `state` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_ticket`
--

LOCK TABLES `dd_ticket` WRITE;
/*!40000 ALTER TABLE `dd_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_transaction`
--

DROP TABLE IF EXISTS `dd_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(288) NOT NULL,
  `content` text NOT NULL,
  `time` varchar(288) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_transaction`
--

LOCK TABLES `dd_transaction` WRITE;
/*!40000 ALTER TABLE `dd_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_transferrecord`
--

DROP TABLE IF EXISTS `dd_transferrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_transferrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(100) NOT NULL,
  `record` mediumtext NOT NULL,
  `time` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_transferrecord`
--

LOCK TABLES `dd_transferrecord` WRITE;
/*!40000 ALTER TABLE `dd_transferrecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_transferrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_user`
--

DROP TABLE IF EXISTS `dd_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `user` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `money` varchar(200) NOT NULL DEFAULT '0',
  `mail` varchar(300) NOT NULL,
  `qq` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `aff` varchar(100) NOT NULL,
  `affmoney` varchar(100) NOT NULL DEFAULT '0',
  `upperid` varchar(100) NOT NULL,
  `time` varchar(200) NOT NULL,
  `state` varchar(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_user`
--

LOCK TABLES `dd_user` WRITE;
/*!40000 ALTER TABLE `dd_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `dd_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dd_web`
--

DROP TABLE IF EXISTS `dd_web`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `dd_web` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  `favicon` text NOT NULL,
  `template` varchar(288) NOT NULL,
  `admintemplate` varchar(288) NOT NULL,
  `wh` varchar(10) NOT NULL DEFAULT '0',
  `whxx` text NOT NULL,
  `email` varchar(100) DEFAULT '0',
  `emailchar` varchar(500) NOT NULL,
  `emailsecure` varchar(100) NOT NULL,
  `emailport` varchar(500) NOT NULL,
  `emailhost` varchar(500) NOT NULL,
  `emailname` varchar(500) NOT NULL,
  `emailpass` varchar(500) NOT NULL,
  `emailauth` varchar(500) NOT NULL,
  `affdiscount` varchar(100) NOT NULL,
  `affwithdrawal` varchar(100) NOT NULL,
  `cronzz` varchar(100) NOT NULL,
  `cronsc` varchar(100) NOT NULL,
  `paycron` varchar(100) NOT NULL,
  `tickcron` varchar(100) NOT NULL,
  `zcyxyz` varchar(100) NOT NULL DEFAULT '0',
  `yxdl` varchar(288) NOT NULL DEFAULT '0',
  `templateset` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dd_web`
--

LOCK TABLES `dd_web` WRITE;
/*!40000 ALTER TABLE `dd_web` DISABLE KEYS */;
INSERT INTO `dd_web` VALUES (1,'江南主机','江南主机,提供快速、稳定、优质的虚拟主机服务！','江南主机,免费主机,公益主机,虚拟主机,香港虚拟主机,美国虚拟主机,免备案虚拟主机','/favicon.ico','default','default','0','<title>维护中...</title>\r\n网站维护中...','0','UTF-8','ssl','666','smtp.qq.com','2150811531@qq.com','123456','true','0.25','10','3','3','5','3','0','0','[{\"name\":\"\\u7f51\\u7ad9\\u80cc\\u666f\",\"title\":\"\\u7f51\\u7ad9\\u80cc\\u666f\",\"type\":\"input\",\"prompt\":\"\\u7f51\\u7ad9\\u80cc\\u666f\\u56fe\\u5730\\u5740 \",\"value\":\"\\/static\\/assets\\/images\\/66.png\"},{\"name\":\"\\u7f51\\u7ad9\\u6807\\u9898\",\"title\":\"\\u7f51\\u7ad9\\u6807\\u9898\",\"type\":\"input\",\"prompt\":\"\\u7f51\\u7ad9\\u9996\\u9875\\u6807\\u9898\",\"value\":\"\\u53ea\\u63d0\\u4f9b\\u5feb\\u901f\\u3001\\u7a33\\u5b9a\\u3001\\u4f18\\u8d28\\u7684\\u865a\\u62df\\u4e3b\\u673a\\u670d\\u52a1!\"},{\"name\":\"\\u516c\\u544a\\u5f00\\u5173\",\"title\":\"\\u662f\\u5426\\u5f00\\u542f\\u516c\\u544a\",\"type\":\"select\",\"prompt\":\"\\u516c\\u544a\\u5f00\\u5173\",\"value\":\"\\u5f00\",\"option\":[\"\\u5f00\",\"\\u5173\"]},{\"name\":\"\\u7f51\\u7ad9\\u516c\\u544a\",\"title\":\"\\u7f51\\u7ad9\\u516c\\u544a\",\"type\":\"textarea\",\"prompt\":\"\\u516c\\u544a\\u5185\\u5bb9,\\u652f\\u6301HTML\",\"value\":\"\\u611f\\u8c22\\u4f60\\u4f7f\\u7528<font color=\\\"red\\\" style=\\\"font-size:20px\\\">\\u6c5f\\u5357\\u4e3b\\u673a<\\/font>~<br\\/>\\u5df2\\u7ecf\\u7ed9\\u65e0\\u6570\\u7684\\u7528\\u6237\\u63d0\\u4f9b\\u8fc7\\u865a\\u62df\\u4e3b\\u673a,\\u6211\\u76f8\\u4fe1\\u6709\\u4f60\\u4eec\\u7684\\u5b58\\u5728,\\u6211\\u4eec\\u4f1a\\u8d70\\u7684\\u66f4\\u8fdc!<br\\/><br\\/>\\u672c\\u7ad9\\u9500\\u552e\\u7cfb\\u7edf\\u51fa\\u552e,<font color=\\\"red\\\" style=\\\"font-size:20px\\\">30\\u5143<\\/font>\\u6388\\u6743<br\\/>\\u5168\\u81ea\\u52a8\\u5316\\u5f00\\u901a,\\u6682\\u505c,\\u7ec8\\u6b62\\u4ea7\\u54c1<br\\/>\\u652f\\u6301\\u670d\\u52a1\\u5668\\u9762\\u677f:bthost,easypanel,mnbt<br\\/>\\u652f\\u4ed8\\u652f\\u6301\\u6613\\u652f\\u4ed8,\\u7801\\u652f\\u4ed8,\\u652f\\u4ed8\\u5b9d\\u5f53\\u9762\\u4ed8<br\\/>\\u53ef\\u81ea\\u4e3b\\u5f00\\u53d1\\u670d\\u52a1\\u5668\\u63d2\\u4ef6\\u548c\\u652f\\u4ed8\\u63d2\\u4ef6!<br\\/>\\u652f\\u6301\\u529f\\u80fd:\\u63a8\\u5e7f\\u8fd4\\u5229,\\u4ea7\\u54c1\\u8fc7\\u6237,\\u81ea\\u52a9\\u5347\\u7ea7\\u4ea7\\u54c1\\u7b49<br\\/><br\\/>\\u5b98\\u65b9QQ\\u7fa4\\uff1a<a href=\\\"http:\\/\\/qm.qq.com\\/cgi-bin\\/qm\\/qr?_wv=1027&k=cAx0B2wnpLKJuxnXXzAwv9Tb9UDB0lCj&authKey=FXMLYeR%2BSJMdJ%2BPBsqo9kxmXmIZunnXOhvoczADvdlj%2FIUffADz5hvupmGZflR74&noverify=0&group_code=905412821\\\" style=\\\"font-size:20px\\\">905412821<\\/a><br\\/><br\\/><h4>\\u7981\\u6b62\\u642d\\u5efa\\u8fdd\\u53cd\\u4e2d\\u56fd\\u7f51\\u7edc\\u6cd5\\u5f8b\\u7684\\u5185\\u5bb9,\\u6bd4\\u5982:\\u5916\\u6302,\\u8bc8\\u9a97,\\u9493\\u9c7c,\\u8d4c\\u535a,\\u8272\\u60c5,VPN\\u7b49,\\u67e5\\u5230\\u76f4\\u63a5\\u5220\\u673a,\\u51bb\\u7ed3\\u8d26\\u6237,\\u4e0d\\u9000\\u6b3e!<\\/h4>\"},{\"name\":\"\\u4fa7\\u8fb9\\u680f\",\"title\":\"\\u4fa7\\u8fb9\\u680f\",\"type\":\"textarea\",\"prompt\":\"\\u4fa7\\u8fb9\\u680f\",\"value\":\"<li class=\\\"nav-main-item\\\">\\r\\n<a class=\\\"nav-main-link\\\" href=\\\"http:\\/\\/qm.qq.com\\/cgi-bin\\/qm\\/qr?_wv=1027&k=cAx0B2wnpLKJuxnXXzAwv9Tb9UDB0lCj&authKey=FXMLYeR%2BSJMdJ%2BPBsqo9kxmXmIZunnXOhvoczADvdlj%2FIUffADz5hvupmGZflR74&noverify=0&group_code=905412821\\\">\\r\\n<i class=\\\"nav-main-link-icon fab fa-qq\\\"><\\/i>\\r\\n<span class=\\\"nav-main-link-name\\\">\\r\\nQQ\\u4ea4\\u6d41\\u7fa4\\r\\n<\\/span>\\r\\n<\\/a>\\r\\n<\\/li>\"},{\"name\":\"\\u7f51\\u7ad9\\u5907\\u6848\\u53f7\",\"title\":\"\\u7f51\\u7ad9\\u5907\\u6848\\u53f7\",\"type\":\"input\",\"prompt\":\"\\u7f51\\u7ad9\\u5907\\u6848\\u53f7 \",\"value\":\"\"}]');
/*!40000 ALTER TABLE `dd_web` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-16  9:37:47
